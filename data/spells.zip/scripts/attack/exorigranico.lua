combat = createCombatObject()
setCombatParam(combat, COMBAT_PARAM_TYPE, COMBAT_PHYSICALDAMAGE)
setCombatParam(combat, COMBAT_PARAM_EFFECT, 27)
setCombatParam(combat, COMBAT_PARAM_USECHARGES, true)

local area = createCombatArea(AREA_SQUARE1X1)
setCombatArea(combat, area)

function onGetFormulaValues(cid, level, skill, attack, factor)
    local skillTotal = skill + attack * 3
    local levelTotal = level / 6
    -- Aumentando os multiplicadores para garantir um dano maior
    local minDmg = -(skillTotal * 10	+ levelTotal * 4)  -- Ajustando para garantir mais dano
    local maxDmg = -(skillTotal * 25 + levelTotal * 4) -- Aumentando o dano máximo
    return minDmg, maxDmg
end

setCombatCallback(combat, CALLBACK_PARAM_SKILLVALUE, "onGetFormulaValues")

function onCastSpell(cid, var)
    if not isMonster(cid) then  -- Verificando se é um jogador
        return doCombat(cid, combat, var)
    end
    return true  -- Caso seja um monstro, nada acontece
end