local combat = Combat()
combat:setParameter(COMBAT_PARAM_TYPE, COMBAT_HEALING)
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_MAGIC_BLUE)
combat:setParameter(COMBAT_PARAM_DISPEL, CONDITION_PARALYZE)
combat:setParameter(COMBAT_PARAM_AGGRESSIVE, false)

function onGetFormulaValues(player, level, magicLevel)
	local vocation = player:getVocation()

	-- Se o jogador for Paladin ou Royal Paladin, cura fixa de 1200
	if vocation:getId() == 3 or vocation:getId() == 7 then
		local min = 1200
		local max = 1200
		return min, max
	end
	
	-- Fórmula padrão para outras vocações
	local min = (level / 5) + (magicLevel * 2.0) + 100
	local max = (level / 5) + (magicLevel * 2.2) + 200
	return min, max
end

combat:setCallback(CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")

function onCastSpell(creature, variant)
	return combat:execute(creature, variant)
end