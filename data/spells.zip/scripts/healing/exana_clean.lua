local combat = Combat()
combat:setParameter(COMBAT_PARAM_EFFECT, CONST_ME_MAGIC_BLUE)
combat:setParameter(COMBAT_PARAM_AGGRESSIVE, false)

-- Lista de condições a serem removidas
local conditionsToDispell = {
    CONDITION_BLEEDING,
    CONDITION_FIRE,
    CONDITION_ENERGY,
    CONDITION_POISON,
    CONDITION_DROWN,
    CONDITION_FREEZING,
    CONDITION_BURN,
    CONDITION_BURNING,  -- Efeito de queimadura
}

function onCastSpell(creature, variant)
    local player = creature:getPlayer()

    if player then
        local removed = false  -- Para verificar se algum veneno foi removido

        -- Remover condições especificadas
        for _, condition in ipairs(conditionsToDispell) do
            if player:getCondition(condition) then  -- Verifica se a condição está presente
                player:removeCondition(condition)  -- Remove a condição
                removed = true  -- Indica que algo foi removido
            end
        end

        -- Envia mensagem ao jogador
        if removed then
            player:sendTextMessage(MESSAGE_STATUS_CONSOLE_BLUE, "Todos os efeitos nocivos foram removidos!")
        else
            player:sendTextMessage(MESSAGE_STATUS_CONSOLE_BLUE, "Voce nao tem efeitos nocivos para remover.")
        end

        -- Exibe animação ou efeito visual da magia
        player:getPosition():sendMagicEffect(CONST_ME_MAGIC_BLUE)
    end

    return combat:execute(creature, variant)
end