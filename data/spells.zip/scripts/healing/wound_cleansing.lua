local combat = createCombatObject()
setCombatParam(combat, COMBAT_PARAM_TYPE, COMBAT_HEALING)
setCombatParam(combat, COMBAT_PARAM_EFFECT, CONST_ME_MAGIC_BLUE)
setCombatParam(combat, COMBAT_PARAM_AGGRESSIVE, false)
setCombatParam(combat, COMBAT_PARAM_DISPEL, CONDITION_PARALYZE)

function onGetFormulaValues(cid, level, maglevel)
	local min = (((level/5)+(maglevel*4)+24.8))
	local max = (((level/5)+(maglevel*8)+50))
	return min, max
end

setCombatCallback(combat, CALLBACK_PARAM_LEVELMAGICVALUE, "onGetFormulaValues")

function onCastSpell(cid, var)
	if getPlayerStorageValue(cid, 3108) <= 0 then
		setPlayerStorageValue(cid, 3108, os.time()+1000)  
		return doRemoveCondition(cid, CONDITION_PARALYZE), doCombat(cid, combat, var)
	else
		doPlayerSendCancel(cid, "You are exhausted.")
	end
end